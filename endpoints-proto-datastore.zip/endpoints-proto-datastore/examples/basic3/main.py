import endpoints

from google.appengine.ext import ndb
from protorpc import remote

from endpoints_proto_datastore.ndb import EndpointsModel

class User(EndpointsModel):
  name = ndb.StringProperty()
  followers = ndb.StringProperty(indexed=True,repeated=True)
# Transitioning an existing model is as easy as replacing ndb.Model with
# EndpointsModel. Since EndpointsModel inherits from ndb.Model, you will have
# the same behavior and more functionality.
class Tweet(EndpointsModel):
  # By default, the ProtoRPC message schema corresponding to this model will
  # have three string fields: attr1, attr2 and created
  # in an arbitrary order (the ordering of properties in a dictionary is not
  # guaranteed).
  sender = ndb.StringProperty()
  parent = ndb.KeyProperty(kind=User)
  body = ndb.StringProperty()
  commonID = ndb.IntegerProperty()
  created = ndb.DateTimeProperty(auto_now_add=True)


# Use of this decorator is the same for APIs created with or without
# endpoints-proto-datastore.
@endpoints.api(name='tinytwittapi', version='v1', description='TinyTwitt API')
class TinyTwittApi(remote.Service):

  @User.method(path='user', http_method='POST', name='user.insert')
  def UserInsert(self, my_model):
    my_model.put()
    return my_model

  @User.method(request_fields=('id',),
                  path='user/{id}', http_method='GET', name='user.get')
  def UserGet(self, my_model):
    if not my_model.from_datastore:
      raise endpoints.NotFoundException('User not found.')
    return my_model



  @Tweet.method(path='tweet', http_method='POST', name='tweet.insert')
  def TweetInsert(self, my_model):
    my_model.put()
    return my_model

  @Tweet.method(request_fields=('id',),
                  path='tweet/{id}', http_method='GET', name='tweet.get')
  def TweetGet(self, my_model):
    if not my_model.from_datastore:
      raise endpoints.NotFoundException('Tweet not found.')
    return my_model

  """
  @Tweet.query_method(path='tweets', name='tweet.list')
  def TweetList(self, query):
    # We have no filters that we need to apply, so we just return the query
    # object as is. As we'll see in further examples, we can augment the query
    # using environment variables and other parts of the request state.
    return query
  """
  """
  @Tweet.query_method(query_fields=('receivers',),
                        path='tweetreceiver', name='tweet.getreceiver')
  def TweetGetReceiver(self, query):
    # We have no filters that we need to apply, so we just return the query
    # object as is. As we'll see in further examples, we can augment the query
    # using environment variables and other parts of the request state.
    return query
"""
# Use of endpoints.api_server is the same for APIs created with or without
# endpoints-proto-datastore.
application = endpoints.api_server([TinyTwittApi], restricted=False)
